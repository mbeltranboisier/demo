package com.example.demo;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Entity
@SuppressWarnings("unused")
public class Tarea {
	
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long identificador;
	@NotBlank(message = "La Descripcion es obligatoria")
	private String descripcion;
	@NotBlank(message = "La Fecha de Creacion es obligatoria")
    private Date fechaCreacion;
	@NotNull
    private boolean vigente;
	
    public Long getIdentificador() {
		return identificador;
	}
	public void setIdentificador(Long identificador) {
		this.identificador = identificador;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(String fechaCreacion) {
		DateFormat dateFormat = new SimpleDateFormat ("dd/MM/yyyy");
		Date date = null;
		try {
			date = dateFormat.parse(fechaCreacion);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.fechaCreacion = date;
	}
	public boolean isVigente() {
		return vigente;
	}
	public void setVigente(boolean vigente) {
		this.vigente = vigente;
	}
 
}
