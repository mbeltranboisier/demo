package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(path="/demo") 
public class MainController {
  @Autowired
  private TareaRepository tareaRepository;

  @PostMapping(path="/insertar") 
  public @ResponseBody String addNewTarea (@RequestParam String desc, @RequestParam String fecha, @RequestParam boolean vig) {
    Tarea t = new Tarea();
    t.setDescripcion(desc);
    t.setFechaCreacion(fecha);
    t.setVigente(vig);
    tareaRepository.save(t);
    return "Insertado Ok";
  }
  
  @PostMapping(path="/actualizar") 
  public @ResponseBody String updateTarea (@RequestParam long id,  @RequestParam String desc, @RequestParam String fecha, @RequestParam boolean vig) {
    Tarea t = tareaRepository.findById(id);
    t.setDescripcion(desc);
    t.setFechaCreacion(fecha);
    t.setVigente(vig);
    tareaRepository.save(t);
    return "Actualizado Ok";
  }

  @GetMapping(path="/listar")
  public @ResponseBody Iterable<Tarea> getAllTareas() {
    // This returns a JSON or XML with the users
    return tareaRepository.findAll();
  }
}
