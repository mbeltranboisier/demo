package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;
import com.example.demo.Tarea;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class TareaServiceController {
	private static Map<String, Tarea> tareas = new HashMap<>();
	
}

